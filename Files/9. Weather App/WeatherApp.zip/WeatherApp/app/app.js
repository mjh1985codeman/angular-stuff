(function() {

	var searchCity = {
		searchInputEl: null,
		
		init: function() {
			this.searchInputEl = document.getElementById("searchInput");
			var submitBtnEl = document.getElementById("submitBtn");
			
			var that = this;
			
			submitBtnEl.addEventListener("click", function() {
				that.onSearch();
			});
		},
		
		onSearch: function() {			
			var cityName = this.searchInputEl.value;
			
			if (cityName.trim() !== "") {
				this.loadCities(cityName);
			} else {
				alert("Please enter city name");
			}
		},
		
		loadCities: function(name) {
			var xhr = null;
			
			if (window.XMLHttpRequest) {
				xhr = new XMLHttpRequest();
			} else {
				xhr = new ActiveXObject("Microsoft.XMLHTTP");
			}
			
			var url = "http://api.openweathermap.org/data/2.5/find?type=like&sort=population&cnt=30&_=1437211739799&q=" + name;
			
			var that = this;
			
			xhr.onreadystatechange = function() {
				if (xhr.readyState === 4 && xhr.status === 200) {
				    var response = JSON.parse(xhr.responseText);
				    
					var cities = response.list;
					
					that.renderCities(cities);
				}
			}
			
			xhr.open("GET", url);
			xhr.send();
		},
		
		renderCities: function(cities) {
			var html = "<ul id='cityList'>";
			
			for (var i = 0; i < cities.length; i++) {
				html += "<li class='city'>" + cities[i].name + "-" + cities[i].main.temp + "</li>";
			}
			
			html += "</ul>";
			
			document.getElementById("cities").innerHTML = html;
			
			var cityListEl = document.getElementById("cityList");
			
			var that = this;
			
			cityListEl.addEventListener("click", function(evt) {
				that.loadCityDetails(evt.target.innerHTML);
			});
		},
		
		loadCityDetails: function(name) {
			var xhr = null;
			
			if (window.XMLHttpRequest) {
				xhr = new XMLHttpRequest();
			} else {
				xhr = new ActiveXObject("Microsoft.XMLHTTP");
			}
			
			var url = "http://api.openweathermap.org/data/2.5/weather?q=" + name;
			
			var that = this;
			
			xhr.onreadystatechange = function() {
				if (xhr.readyState === 4 && xhr.status === 200) {
				    var response = JSON.parse(xhr.responseText);
					
					console.log(response);
				}
			}
			
			xhr.open("GET", url);
			xhr.send();
		}
	}
	
	searchCity.init();

}());