﻿(function () {
    var name = "app.forecast",
        requires = [];

    angular.module(name, requires);
})();