﻿(function () {
    var name = "app.weather",
        requires = [];

    angular.module(name, requires);
})();